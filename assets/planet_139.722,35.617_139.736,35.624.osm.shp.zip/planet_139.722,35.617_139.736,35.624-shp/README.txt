Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Sat 15 May 2021 04:33:27 AM UTC
GPS rectangle coordinates (lng,lat): 139.722,35.617 x 139.736,35.624
Script URL: https://extract.bbbike.org?sw_lng=139.722&sw_lat=35.617&ne_lng=139.736&ne_lat=35.624&format=shp.zip&layers=00B0T&city=%E5%A4%A7%E5%B4%8E%2C+%E5%B1%B1%E6%89%8B%E9%80%9A%E3%82%8A%2C+%E5%A4%A7%E5%B4%8E%E4%B8%80%E4%B8%81%E7%9B%AE%2C+%E5%93%81%E5%B7%9D%E5%8C%BA%2C+%E6%9D%B1%E4%BA%AC%E9%83%BD%2C+141-0032%2C+%E6%97%A5%E6%9C%AC&lang=en
Name of area: 大崎, 山手通り, 大崎一丁目, 品川区, 


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 10 Euro (12 USD) by the end of the day or
300 Euro (350USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
